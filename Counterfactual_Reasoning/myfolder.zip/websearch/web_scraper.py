"""High-level WebSearcher: search → fetch pages/PDFs → optional semantic filter.

This is the main entry point for the websearch package.

Typical usage
-------------
Simple search only (no LLM, no page fetching):

    async with WebSearcher(serper_api_key="...") as ws:
        result = await ws.search("CRISPR cancer therapy", num_results=5)
        print(result.formatted_text)

Search + fetch page content:

    async with WebSearcher(serper_api_key="...") as ws:
        result = await ws.search_and_fetch("APP protein P05067 function", fetch_top_n=2)
        for item in result.contents:
            print(item["url"], item["content"][:300])

Full pipeline with LLM-guided search + semantic filter:

    from websearch import WebSearcher, OpenAIAdapterSampler

    sampler = OpenAIAdapterSampler(api_key="...", base_url="...", model="gpt-4o-mini")
    async with WebSearcher(serper_api_key="...",
                           openai_api_key="...",
                           openai_base_url="...") as ws:
        result = await ws.search_fetch_and_filter(
            claim="APP protein has Kunitz-type protease inhibitor domains",
            sampler=sampler,
            max_searches=3,
            max_output_words=1500,
        )
        print(result.filtered_content)
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .browser_fetcher import fetch_html, extract_text_from_html, extract_pdf_links, close_http_client
from .pdf_extractor import extract_pdf_as_markdown, check_if_url_is_pdf, close_pdf_session
from .semantic_filter import extract_relevant_sentences
from .serper_client import SerperSearchClient
from .bright_data_client import BrightDataSearchClient
from .types import SamplerBase, SamplerResponse

_logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class WebSearchResult:
    """Structured result returned by WebSearcher methods."""

    # Always present
    query: str = ""
    queries_executed: List[str] = field(default_factory=list)
    formatted_snippets: str = ""            # Serper snippets only (fast, no HTTP)
    urls_fetched: List[str] = field(default_factory=list)

    # Populated after fetch
    contents: List[Dict[str, Any]] = field(default_factory=list)
    """Each item: {url, title, snippet, content (Markdown)}"""

    # Populated after semantic filter
    filtered_content: str = ""

    # Stats
    usage: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Adapter: wrap an AutoGen / OpenAI client as SamplerBase
# ---------------------------------------------------------------------------

class OpenAIAdapterSampler(SamplerBase):
    """Minimal SamplerBase wrapper around openai.AsyncOpenAI.

    Use this to plug the WebSearcher's LLM-guided search planner into
    any OpenAI-compatible endpoint (including the agdebugger's custom one).

    Example::

        sampler = OpenAIAdapterSampler(
            api_key="sk-...",
            base_url="http://34.13.73.248:3888/v1",
            model="gpt-4o-mini",
        )
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        base_url: str | None = None,
    ):
        from openai import AsyncOpenAI
        import httpx

        http_client = httpx.AsyncClient(
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
            timeout=httpx.Timeout(60.0, connect=15.0),
            http1=True,
            http2=False,
        )
        kwargs: Dict[str, Any] = dict(api_key=api_key, http_client=http_client)
        if base_url:
            kwargs["base_url"] = base_url
        self._client = AsyncOpenAI(**kwargs)
        self._model = model

    async def __call__(self, message_list) -> SamplerResponse:
        resp = await self._client.chat.completions.create(
            model=self._model,
            messages=message_list,
        )
        choice = resp.choices[0]
        usage = resp.usage
        return SamplerResponse(
            response_text=choice.message.content or "",
            actual_queried_message_list=message_list,
            response_metadata={},
            token_usage={
                "input_tokens": usage.prompt_tokens if usage else 0,
                "output_tokens": usage.completion_tokens if usage else 0,
                "total_tokens": usage.total_tokens if usage else 0,
                "cached_tokens": 0,
                "reasoning_tokens": 0,
            },
        )


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class WebSearcher:
    """Search the web, optionally fetch pages/PDFs and apply semantic filtering.

    Args:
        serper_api_key:  Serper API key (falls back to ``SERPER_API_KEY`` env var).
        openai_api_key:  OpenAI-compatible API key for embeddings (semantic filter).
        openai_base_url: Base URL for OpenAI-compatible embedding endpoint.
        max_html_words:  Truncate fetched HTML to this many words (default: 5000).
        log_level:       Logging level for the internal logger.
    """

    def __init__(
        self,
        serper_api_key: str | None = None,
        openai_api_key: str | None = None,
        openai_base_url: str | None = None,
        max_html_words: int = 5000,
        log_level: int = logging.WARNING,
        # Bright Data options (take precedence over serper_api_key when set)
        bright_data_api_key: str | None = None,
        bright_data_zone: str | None = None,
        # PDF download options
        pdf_timeout_seconds: int = 60,
        pdf_max_retries: int = 1,
        pdf_max_size_mb: int = 5,
    ):
        self._serper_api_key = serper_api_key
        self._openai_api_key = openai_api_key
        self._openai_base_url = openai_base_url
        self._max_html_words = max_html_words
        self._bright_data_api_key = bright_data_api_key
        self._bright_data_zone = bright_data_zone
        self._pdf_timeout_seconds = pdf_timeout_seconds
        self._pdf_max_retries = pdf_max_retries
        self._pdf_max_size_mb = pdf_max_size_mb
        self._serper: SerperSearchClient | None = None

        logging.getLogger("websearch").setLevel(log_level)

    # -- Lifecycle -----------------------------------------------------------

    async def start(self) -> None:
        # Prefer Bright Data when its key is provided or available via env var
        import os
        bd_key = self._bright_data_api_key or os.environ.get("BRIGHT_DATA_API_KEY", "")
        if bd_key:
            self._serper = BrightDataSearchClient(
                api_key=bd_key,
                zone=self._bright_data_zone,
            )
        else:
            self._serper = SerperSearchClient(api_key=self._serper_api_key)
        await self._serper.start()

    async def close(self) -> None:
        if self._serper:
            await self._serper.close()
        await close_http_client()
        await close_pdf_session()

    async def __aenter__(self) -> "WebSearcher":
        await self.start()
        return self

    async def __aexit__(self, *_) -> None:
        await self.close()

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------

    async def search(
        self,
        query: str,
        num_results: int = 5,
    ) -> WebSearchResult:
        """Run a single Serper search and return snippets (no page fetching).

        This is the cheapest / fastest method – great for a quick sanity check.
        """
        self._ensure_started()
        raw, _ = await self._serper.search(query, num_results)
        return WebSearchResult(
            query=query,
            queries_executed=[query],
            formatted_snippets=self._serper._format_single_result(raw),
            urls_fetched=[r["link"] for r in raw.get("organic", []) if r.get("link")],
        )

    async def search_and_fetch(
        self,
        query: str,
        num_results: int = 5,
        fetch_top_n: int = 2,
        also_fetch_pdfs: bool = True,
    ) -> WebSearchResult:
        """Search + fetch and parse the top *fetch_top_n* pages.

        Args:
            query:          Search query string.
            num_results:    Number of Serper results to request.
            fetch_top_n:    How many of the top results to actually fetch.
            also_fetch_pdfs: If a page links to PDFs, download and parse them too.

        Returns:
            WebSearchResult with ``contents`` list populated.
        """
        self._ensure_started()

        raw, _ = await self._serper.search(query, num_results)
        organic = raw.get("organic", [])
        urls = [r["link"] for r in organic[:fetch_top_n] if r.get("link")]
        snippets_map = {r["link"]: r.get("snippet", "") for r in organic if r.get("link")}
        titles_map = {r["link"]: r.get("title", "") for r in organic if r.get("link")}

        contents = await self._fetch_urls(urls, snippets_map, titles_map, also_fetch_pdfs)

        return WebSearchResult(
            query=query,
            queries_executed=[query],
            formatted_snippets=self._serper._format_single_result(raw),
            urls_fetched=urls,
            contents=contents,
        )

    async def search_fetch_and_filter(
        self,
        claim: str,
        sampler: Optional[SamplerBase] = None,
        max_searches: int = 3,
        num_results: int = 5,
        fetch_top_n: int = 2,
        also_fetch_pdfs: bool = True,
        max_output_words: int = 1500,
        embedding_model: str = "text-embedding-3-small",
    ) -> WebSearchResult:
        """Full pipeline: LLM-guided search → fetch pages → semantic filter.

        If *sampler* is None the search falls back to a single non-guided query.

        Args:
            claim:            The claim / question to verify or answer.
            sampler:          LLM sampler for multi-step search planning.
                              Pass ``None`` for a simple single-step search.
            max_searches:     Maximum LLM-guided search iterations.
            num_results:      Serper results per search step.
            fetch_top_n:      Pages to fetch from the final URL selection.
            also_fetch_pdfs:  Also parse PDF links found on fetched pages.
            max_output_words: Word budget for the semantic filter output.
            embedding_model:  OpenAI embedding model for semantic filter.

        Returns:
            WebSearchResult with ``contents`` and ``filtered_content`` populated.
        """
        self._ensure_started()

        # Step 1: search
        if sampler is not None:
            (raw_results, formatted, queries, urls_pos, usage, top_urls) = (
                await self._serper.perform_verification_search(
                    claim_text=claim,
                    sampler=sampler,
                    max_searches=max_searches,
                    num_results=num_results,
                )
            )
        else:
            raw, _ = await self._serper.search(claim, num_results)
            raw_results = [raw]
            formatted = self._serper._format_single_result(raw)
            queries = [claim]
            usage = {}
            top_urls = [r["link"] for r in raw.get("organic", [])[:fetch_top_n] if r.get("link")]

        # Gather URLs to fetch
        fetch_urls = top_urls[:fetch_top_n]

        snippets_map = {
            r["link"]: r.get("snippet", "")
            for step in raw_results
            for r in step.get("organic", [])
            if r.get("link")
        }
        titles_map = {
            r["link"]: r.get("title", "")
            for step in raw_results
            for r in step.get("organic", [])
            if r.get("link")
        }

        # Step 2: fetch
        contents = await self._fetch_urls(fetch_urls, snippets_map, titles_map, also_fetch_pdfs)

        # Step 3: semantic filter
        filtered = ""
        if contents and self._openai_api_key:
            filtered = await extract_relevant_sentences(
                websearch_results=contents,
                claim=claim,
                max_output_words=max_output_words,
                embedding_model=embedding_model,
                openai_api_key=self._openai_api_key,
                openai_base_url=self._openai_base_url,
            )

        return WebSearchResult(
            query=claim,
            queries_executed=queries,
            formatted_snippets=formatted,
            urls_fetched=fetch_urls,
            contents=contents,
            filtered_content=filtered,
            usage=usage,
        )

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _ensure_started(self) -> None:
        if self._serper is None:
            raise RuntimeError("WebSearcher not started. Use 'async with WebSearcher(...):'")

    async def _fetch_single_url(
        self,
        url: str,
        snippet: str,
        title: str,
        also_fetch_pdfs: bool,
    ) -> List[Dict[str, Any]]:
        """Fetch one URL and return a list of content dicts (HTML + any PDFs)."""
        items: List[Dict[str, Any]] = []

        # Check if this URL itself is a PDF
        if await check_if_url_is_pdf(url):
            md = await extract_pdf_as_markdown(
                url,
                timeout_seconds=self._pdf_timeout_seconds,
                max_retries=self._pdf_max_retries,
                max_pdf_size_mb=self._pdf_max_size_mb,
            )
            if md:
                items.append({"url": url, "title": title, "snippet": snippet, "content": md})
            return items

        # Fetch HTML
        html = await fetch_html(url)
        if not html:
            return items

        text = await extract_text_from_html(html, source_url=url, max_words=self._max_html_words)
        if text:
            items.append({"url": url, "title": title, "snippet": snippet, "content": text})

        # Optionally fetch PDF links found on the page
        if also_fetch_pdfs:
            pdf_urls = extract_pdf_links(html, base_url=url)
            for pdf_url in pdf_urls[:1]:  # limit to 1 PDF per page
                md = await extract_pdf_as_markdown(
                    pdf_url,
                    timeout_seconds=self._pdf_timeout_seconds,
                    max_retries=self._pdf_max_retries,
                    max_pdf_size_mb=self._pdf_max_size_mb,
                )
                if md:
                    items.append({
                        "url": pdf_url,
                        "title": f"{title} (PDF)",
                        "snippet": "",
                        "content": md,
                    })

        return items

    async def _fetch_urls(
        self,
        urls: List[str],
        snippets_map: Dict[str, str],
        titles_map: Dict[str, str],
        also_fetch_pdfs: bool,
    ) -> List[Dict[str, Any]]:
        """Fetch all URLs concurrently and return a flat list of content dicts."""
        tasks = [
            self._fetch_single_url(
                url,
                snippets_map.get(url, ""),
                titles_map.get(url, ""),
                also_fetch_pdfs,
            )
            for url in urls
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        contents: List[Dict[str, Any]] = []
        for res in results:
            if isinstance(res, Exception):
                _logger.warning(f"Fetch error: {res}")
            else:
                contents.extend(res)
        return contents
