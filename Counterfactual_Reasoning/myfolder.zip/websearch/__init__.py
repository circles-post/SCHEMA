"""websearch – self-contained web search, page fetching, PDF parsing and semantic filtering.

Public API
----------
WebSearcher        High-level orchestrator (search → fetch → filter).
OpenAIAdapterSampler  Wrap an OpenAI-compatible client as a search planner.
WebSearchResult    Structured result dataclass.

Low-level helpers (import directly if needed):
    SerperSearchClient  – raw Serper API client
    fetch_html          – async httpx page fetcher
    extract_text_from_html – trafilatura text extraction
    extract_pdf_as_markdown – PDF download + MarkItDown conversion
    extract_relevant_sentences – embedding-based semantic filter
    split_into_blocks   – text chunker
"""

from .web_scraper import WebSearcher, OpenAIAdapterSampler, WebSearchResult
from .serper_client import SerperSearchClient
from .bright_data_client import BrightDataSearchClient
from .browser_fetcher import fetch_html, extract_text_from_html, extract_pdf_links
from .pdf_extractor import extract_pdf_as_markdown, is_pdf_url, check_if_url_is_pdf
from .semantic_filter import extract_relevant_sentences, split_into_blocks
from .types import SamplerBase, SamplerResponse

__all__ = [
    # High-level
    "WebSearcher",
    "OpenAIAdapterSampler",
    "WebSearchResult",
    # Mid-level
    "SerperSearchClient",
    "BrightDataSearchClient",
    # Low-level
    "fetch_html",
    "extract_text_from_html",
    "extract_pdf_links",
    "extract_pdf_as_markdown",
    "is_pdf_url",
    "check_if_url_is_pdf",
    "extract_relevant_sentences",
    "split_into_blocks",
    # Base types
    "SamplerBase",
    "SamplerResponse",
]
