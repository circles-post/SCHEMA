"""PDF download and conversion to Markdown.

Adapted from halluhard/libs/information_extraction.py (PDF portion only).
Uses MarkItDown for conversion and httpx for async downloading.
"""

from __future__ import annotations

import asyncio
import gc
import logging
import os
import random
import tempfile
import uuid
from pathlib import Path
from urllib.parse import urlparse

import httpx
import markitdown

_logger = logging.getLogger(__name__)

_PDF_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "application/pdf,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

_pdf_client: httpx.AsyncClient | None = None


async def _get_pdf_client() -> httpx.AsyncClient:
    global _pdf_client
    if _pdf_client is None or _pdf_client.is_closed:
        _pdf_client = httpx.AsyncClient(
            timeout=httpx.Timeout(60.0, connect=15.0),
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=30),
            headers=_PDF_HEADERS,
            follow_redirects=True,
            http1=True,
            http2=False,
        )
    return _pdf_client


async def close_pdf_session() -> None:
    """Close the shared PDF client. Call at program shutdown."""
    global _pdf_client
    if _pdf_client is not None and not _pdf_client.is_closed:
        await _pdf_client.aclose()
        _pdf_client = None


def is_pdf_url(url: str) -> bool:
    """Return True if *url* likely points to a PDF file (pattern-based check)."""
    if not url or not url.strip():
        return False
    url_lower = url.lower()
    path = urlparse(url_lower).path
    return (
        path.endswith(".pdf")
        or "/pdf/" in path
        or ".pdf?" in path
        or path.endswith(".pdf/")
        or "arxiv.org/pdf/" in url_lower
    )


async def check_if_url_is_pdf(url: str) -> bool:
    """Return True if URL is a PDF (URL pattern OR Content-Type header check)."""
    if is_pdf_url(url):
        return True
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(10.0)) as c:
            r = await c.head(url, follow_redirects=True)
            ct = r.headers.get("Content-Type", "").lower()
            return "application/pdf" in ct
    except Exception:
        return False


async def extract_pdf_as_markdown(
    url: str,
    max_retries: int = 1,
    timeout_seconds: int = 30,
    max_pdf_size_mb: int = 2,
    conversion_timeout_seconds: int = 60,
    pdf_semaphore: asyncio.Semaphore | None = None,
) -> str | None:
    """Download PDF from *url* and convert to Markdown string.

    Returns the Markdown text, or None if the URL is not a PDF / conversion fails.

    Args:
        url: PDF URL to download.
        max_retries: Download retry attempts on timeout.
        timeout_seconds: HTTP download timeout in seconds.
        max_pdf_size_mb: Skip PDFs larger than this (MB).
        conversion_timeout_seconds: MarkItDown conversion timeout in seconds.
        pdf_semaphore: Optional semaphore to cap concurrent downloads.
    """
    if not is_pdf_url(url):
        return None

    async def _run() -> str | None:
        for attempt in range(max_retries + 1):
            temp_dir = tempfile.mkdtemp()
            temp_pdf_path = Path(temp_dir) / f"downloaded_{uuid.uuid4()}.pdf"
            try:
                _logger.warning(f"PDF download attempt {attempt+1}/{max_retries+1}: {url[:80]}")
                client = await _get_pdf_client()

                # Stream download with progress display
                async with client.stream(
                    "GET", url,
                    timeout=httpx.Timeout(timeout_seconds, connect=15.0),
                ) as resp:
                    if resp.status_code != 200:
                        _logger.warning(f"PDF download failed HTTP {resp.status_code}: {url[:80]}")
                        return None
                    ct = resp.headers.get("Content-Type", "").lower()
                    if "application/pdf" not in ct and not is_pdf_url(url):
                        _logger.warning(f"Not a PDF (Content-Type={ct}): {url[:80]}")
                        return None

                    total_bytes = int(resp.headers.get("Content-Length", 0))
                    total_mb = total_bytes / (1024 * 1024) if total_bytes else 0
                    chunks = []
                    downloaded = 0
                    last_print = 0
                    async for chunk in resp.aiter_bytes(65536):
                        chunks.append(chunk)
                        downloaded += len(chunk)
                        if downloaded - last_print >= 256 * 1024 or (total_bytes and downloaded >= total_bytes):
                            downloaded_mb = downloaded / (1024 * 1024)
                            if total_mb:
                                pct = downloaded / total_bytes * 100
                                print(f"\r  Downloading: {downloaded_mb:.1f} / {total_mb:.1f} MB  ({pct:.0f}%)", end="", flush=True)
                            else:
                                print(f"\r  Downloading: {downloaded_mb:.1f} MB", end="", flush=True)
                            last_print = downloaded
                    print()  # newline after progress
                    pdf_bytes = b"".join(chunks)

                size_mb = len(pdf_bytes) / (1024 * 1024)
                if size_mb > max_pdf_size_mb:
                    _logger.warning(f"PDF too large ({size_mb:.1f} MB > {max_pdf_size_mb} MB): {url[:80]}")
                    return None

                with open(temp_pdf_path, "wb") as f:
                    f.write(pdf_bytes)

                # Convert in thread pool (MarkItDown is blocking)
                print("  Converting PDF to Markdown...", flush=True)
                loop = asyncio.get_event_loop()
                md = markitdown.MarkItDown()
                try:
                    result = await asyncio.wait_for(
                        loop.run_in_executor(None, lambda: md.convert(str(temp_pdf_path))),
                        timeout=conversion_timeout_seconds,
                    )
                    return result.text_content
                except asyncio.TimeoutError:
                    _logger.warning(f"MarkItDown timeout after {conversion_timeout_seconds}s: {url[:80]}")
                    return None
                except Exception as e:
                    _logger.warning(f"MarkItDown error: {e}")
                    return None

            except httpx.TimeoutException:
                if attempt < max_retries:
                    wait = 2 ** attempt + random.uniform(0, 1)
                    _logger.warning(f"PDF timeout, retry in {wait:.0f}s: {url[:80]}")
                    await asyncio.sleep(wait)
                    continue
                _logger.warning(f"PDF download timeout after {max_retries+1} attempts: {url[:80]}")
                return None
            except Exception as e:
                _logger.warning(f"PDF error for {url[:80]}: {e}")
                return None
            finally:
                gc.collect()
                for _ in range(3):
                    try:
                        if temp_pdf_path.exists():
                            os.remove(temp_pdf_path)
                        os.rmdir(temp_dir)
                        break
                    except Exception:
                        await asyncio.sleep(0.1)
        return None

    if pdf_semaphore:
        async with pdf_semaphore:
            return await _run()
    return await _run()
