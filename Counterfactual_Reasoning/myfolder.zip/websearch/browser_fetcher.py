"""Async webpage fetcher: httpx + trafilatura for content extraction.

Adapted from halluhard/libs/browser_fetcher.py.
Selenium branch (commented out in original) is not included here.
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import List
from urllib.parse import urljoin, urlparse, urlunparse, parse_qs, urlencode

from bs4 import BeautifulSoup
import httpx
import trafilatura

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Shared HTTP Client (connection pool)
# ---------------------------------------------------------------------------

_http_client: httpx.AsyncClient | None = None

_DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

_TRACKING_PARAMS = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "fbclid", "gclid", "msclkid", "mc_cid", "mc_eid",
    "_ga", "_gid", "_hsenc", "_hsmi",
    "ref", "referrer", "source",
}


async def _get_http_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.AsyncClient(
            follow_redirects=True,
            timeout=httpx.Timeout(20.0, connect=10.0),
            limits=httpx.Limits(max_connections=30, max_keepalive_connections=15),
            headers=_DEFAULT_HEADERS,
            verify=True,
            http1=True,
            http2=False,
        )
    return _http_client


async def close_http_client() -> None:
    """Close the shared HTTP client. Call at program shutdown."""
    global _http_client
    if _http_client is not None and not _http_client.is_closed:
        await _http_client.aclose()
        _http_client = None


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def normalize_url(url: str) -> str:
    """Remove common tracking parameters from a URL."""
    try:
        parsed = urlparse(url)
        if parsed.query:
            params = parse_qs(parsed.query, keep_blank_values=True)
            filtered = {k: v for k, v in params.items() if k.lower() not in _TRACKING_PARAMS}
            new_query = urlencode(filtered, doseq=True) if filtered else ""
            return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, ""))
        return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, "", ""))
    except Exception:
        return url


async def fetch_html(url: str, timeout: int = 20, max_retries: int = 2) -> str | None:
    """Fetch raw HTML from *url* asynchronously.

    Returns the HTML string or None on failure.
    """
    clean_url = normalize_url(url)

    for attempt in range(max_retries + 1):
        try:
            await asyncio.sleep(random.uniform(0, 0.2))
            client = await _get_http_client()
            response = await client.get(clean_url, timeout=timeout)
            response.raise_for_status()
            html = response.text
            if not html or len(html) < 500:
                return None
            return html

        except httpx.HTTPStatusError as e:
            _logger.debug(f"HTTP {e.response.status_code} for {clean_url[:80]}")
            return None
        except (httpx.TimeoutException, httpx.ConnectError, OSError) as e:
            if attempt < max_retries:
                wait = 2 ** attempt + random.uniform(0, 1)
                _logger.debug(f"Retrying in {wait:.1f}s ({type(e).__name__})")
                await asyncio.sleep(wait)
                continue
            _logger.debug(f"Failed after {max_retries} retries: {type(e).__name__}")
            return None
        except Exception as e:
            err = str(e)
            if "SSL" not in err and "certificate" not in err:
                _logger.debug(f"Unexpected error for {clean_url[:80]}: {type(e).__name__}")
            return None

    return None


async def extract_text_from_html(html: str, source_url: str = "", max_words: int | None = None) -> str:
    """Extract main content from HTML using trafilatura, returning Markdown.

    Runs trafilatura in the thread-pool (CPU-bound).
    """
    try:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: trafilatura.extract(
                html,
                include_comments=False,
                include_tables=True,
                include_images=False,
                include_links=True,
                output_format="markdown",
                url=source_url or None,
                favor_recall=True,
            ),
        )
        text = result or ""
        if max_words:
            words = text.split()
            if len(words) > max_words:
                text = " ".join(words[:max_words]) + f"\n\n[Content truncated at {max_words} words]"
        return text
    except Exception as e:
        _logger.debug(f"trafilatura failed: {e}")
        return ""


def extract_pdf_links(html_content: str, base_url: str | None = None) -> List[str]:
    """Return all PDF URLs found in *html_content*."""
    if not html_content:
        return []
    try:
        soup = BeautifulSoup(html_content, "html.parser")
        links = []
        for tag in soup.find_all("a", href=True):
            href = tag["href"]
            hl = href.lower()
            if hl.endswith(".pdf") or "/pdf/" in hl or ".pdf?" in hl or hl.endswith(".pdf/"):
                absolute = urljoin(base_url, href) if base_url else href
                parsed = urlparse(absolute)
                if parsed.scheme in ("http", "https", "") and absolute not in links:
                    links.append(absolute)
        return links
    except Exception as e:
        _logger.warning(f"Error extracting PDF links: {e}")
        return []
